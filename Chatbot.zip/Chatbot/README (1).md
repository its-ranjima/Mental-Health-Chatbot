
Mental Health Chatbot


This chatbot is designed to assist users in managing their mental health by analyzing text inputs using NLP and deep learning. It can detect emotional states, provide supportive responses, and offer mental health resources.

Features

* Uses Natural Language Processing (NLP) to analyze user inputs.

* Detects emotional states and stress levels.

* Provides mental health resources and supportive messages.

* Integrates with external mental health databases for accurate   information.

* AI-driven personalized responses using deep learning models.